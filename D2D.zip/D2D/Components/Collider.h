#pragma once
#include "Component.h"
#include "Utilities/Collision.h"
#include "Components/Transform.h"

enum class ColliderType { POINT, BOX, CIRCLE };

class Collider : public Component
{
public:
	Collider(ColliderType type) : Component("Collider"), type(type) {}
	virtual ~Collider() = default;

	virtual bool IsCollidingWith(ColliderType type, Vector2 position, Vector2 scale) = 0; //�浹 Ȯ���� ��ü�� ����, �� ��ü�� ��ġ�� ũ��.

	ColliderType GetType() const { return type; }

protected:
	ColliderType type;
};