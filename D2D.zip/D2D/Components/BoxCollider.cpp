#include "stdafx.h"
#include "BoxCollider.h"
#include "CircleCollider.h"
#include "Components/Transform.h"
#include "Objects/Object.h"

bool BoxCollider::IsCollidingWith(ColliderType type, Vector2 position, Vector2 scale)
{
	const auto& tr = GetOwner()->GetTransform();

	//type ���ڰ��� ���� Collision::Intersect ���� (BoxCollider �̱⿡ �ڽ��� ������ RectData)
	switch (type)
	{
	case ColliderType::POINT:
	{
		return Collision::Intersect(Collision::RectData(tr->GetPosition(), tr->GetScale()), position);
	}
	case ColliderType::BOX:
	{
		return Collision::Intersect(Collision::RectData(tr->GetPosition(), tr->GetScale()), Collision::RectData(position, scale));
	}
	case ColliderType::CIRCLE:
	{
		return Collision::Intersect(Collision::RectData(tr->GetPosition(), tr->GetScale()), Collision::CircleData(position, scale));
	}
	break;
	}
	// �浹 ���� �ʾҰų� ColliderType enum�� ���� �ʴ� ���� �Է��ߴٸ� false ��ȯ
	return false;
}

bool BoxCollider::IsCollidingWithOBB(shared_ptr<Transform> target)
{
	const auto& tr = GetOwner()->GetTransform();

	return Collision::IntersectOBB(tr, target);
}