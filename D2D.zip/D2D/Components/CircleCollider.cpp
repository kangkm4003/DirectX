#include "stdafx.h"
#include "CircleCollider.h"
#include "Components/Transform.h"
#include "Objects/Object.h"

bool CircleCollider::IsCollidingWith(ColliderType type, Vector2 position, Vector2 scale)
{
	const auto& tr = GetOwner()->GetTransform();

	//type ���ڰ��� ���� Collision::Intersect ���� (CircleCollider �̱⿡ �ڽ��� ������ CircleData)
	switch (type)
	{
	case ColliderType::POINT:
	{
		return Collision::Intersect(Collision::CircleData(tr->GetPosition(), tr->GetScale()), position);
	}
	case ColliderType::BOX:
	{
		return Collision::Intersect(Collision::CircleData(tr->GetPosition(), tr->GetScale()), Collision::RectData(position, scale));
	}
	case ColliderType::CIRCLE:
	{
		return Collision::Intersect(Collision::CircleData(tr->GetPosition(), tr->GetScale()), Collision::CircleData(position, scale));
	}
	break;
	}
	return false;
}